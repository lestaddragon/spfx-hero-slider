export enum ComponentStatus {
    Error,
    MissingConfiguration,
    Loading,
    Completed,
}