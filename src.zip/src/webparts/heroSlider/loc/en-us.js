define([], function() {
  return {
    PropertyPaneDescription: 'Slider web part to display web site news',
    VisibilityGroupName: '- - - Visibility - - -',
    HideControlsFieldLabel: 'Check to hide arrow controls',
    HideNavigationFieldLabel: 'Enable to hide navigation',
    LimitsGroupName: '- - - Limits - - -',
    SlidesLimitFieldLabel: 'Limit amount of slides to display',
    ContentTypeGroupName: '- - - Content Type - - -',
    ContentTypeNameFieldLabel: 'Content Type Name',
  };
});
