export { default as HeroSlider } from './HeroSlider';
