/* tslint:disable */
require("./HeroSlider.module.css");
const styles = {
  slider: 'slider_caac5d3d',
};

export default styles;
/* tslint:enable */