/* tslint:disable */
require("./Slide.module.css");
const styles = {
  slide: 'slide_e75a7a5d',
  headline: 'headline_e75a7a5d',
  category: 'category_e75a7a5d',
  title: 'title_e75a7a5d',
  description: 'description_e75a7a5d',
  cta: 'cta_e75a7a5d',
};

export default styles;
/* tslint:enable */