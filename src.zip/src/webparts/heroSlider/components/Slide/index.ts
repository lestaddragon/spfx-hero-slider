export { default as Slide } from './Slide';
