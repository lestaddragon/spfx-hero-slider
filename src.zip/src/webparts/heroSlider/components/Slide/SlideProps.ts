import { Slide } from '../../models/Slide';

export default interface SlideProps extends Slide {
  isActive: boolean;
}