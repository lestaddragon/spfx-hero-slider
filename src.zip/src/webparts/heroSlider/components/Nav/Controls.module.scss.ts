/* tslint:disable */
require("./Controls.module.css");
const styles = {
  slider: 'slider_ffd1b1a8',
};

export default styles;
/* tslint:enable */