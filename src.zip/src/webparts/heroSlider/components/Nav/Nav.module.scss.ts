/* tslint:disable */
require("./Nav.module.css");
const styles = {
};

export default styles;
/* tslint:enable */