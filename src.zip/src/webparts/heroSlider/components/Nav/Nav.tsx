import * as React from 'react';
import { NavProps } from './NavProps';

const Nav: React.StatelessComponent<NavProps> = props => {
  return <div>Nav</div>;
}

export default Nav;