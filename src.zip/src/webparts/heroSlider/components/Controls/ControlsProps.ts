export interface ControlsProps {
    goPrevious(): void;
    goNext(): void;
}