/* tslint:disable */
require("./HeroSlider.module.css");
const styles = {
  slider: 'slider_86818ab3',
};

export default styles;
/* tslint:enable */