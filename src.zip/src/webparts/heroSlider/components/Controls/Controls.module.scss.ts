/* tslint:disable */
require("./Controls.module.css");
const styles = {
  controls: 'controls_5868d864',
  arrowLeft: 'arrowLeft_5868d864',
  arrowRight: 'arrowRight_5868d864',
};

export default styles;
/* tslint:enable */