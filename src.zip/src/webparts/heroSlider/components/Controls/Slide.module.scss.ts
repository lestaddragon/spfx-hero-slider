/* tslint:disable */
require("./Slide.module.css");
const styles = {
  slider: 'slider_93fa8005',
};

export default styles;
/* tslint:enable */